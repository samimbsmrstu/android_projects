 <?php include'header.php' ;?>
<?php include'connection.php' ;?>

 <div class="col-lg-12">
                <?php
                		$sid= $_POST['SUPERVISOR_ID'];
						$sname= $_POST['SUPERVISOR_NAME'];
					    $edate= $_POST['EMPLOY_DATE'];
					    $nid= $_POST['NATIONAL_ID'];
					    $bdate= $_POST['BIRTH_DATE'];
						
						
				
					switch($_GET['action']){
						case 'add':			
								$query = "INSERT INTO supervisor
								(SUPERVISOR_ID,SUPERVISOR_NAME,EMPLOY_DATE,NATIONAL_ID,BIRTH_DATE)
								VALUES ('".$sid."','".$sname."','".$edate."','".$nid."','".$bdate."')";
								mysqli_query($db,$query)or die (mysqli_error($db));
							
						break;
									
						}
				?>
    	<script type="text/javascript">
			alert("Successfully added.");
			window.location = "supervisor.php";
		</script>
                    </div>