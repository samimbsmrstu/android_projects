<?php include 'connection.php';
include 'topnav.php'; ?>
 <div class="col-lg-12">
                        <div>
            <i class="fas fa-table"></i>

               Supervisor Records  <a href="supervisoradd.php?action=add"  style="background-image: linear-gradient();> type="button" class="btn btn-xs btn-info">Add New</a>
            </div>    

                          <br> </br>      
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Supervisor ID</th>
                                        <th>Supervisor Name</th>
                                        <th>Employ Date</th>
                                        <th>National ID</th>
                                        <th>Birth Date</th>
                                        <th>Options</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php                  
                $query = 'SELECT * FROM supervisor';
                    $result = mysqli_query($db, $query) or die (mysqli_error($db));
                  
                        while ($row = mysqli_fetch_assoc($result)) {
                                             
                            echo '<td>'. $row['SUPERVISOR_ID'].'</td>';
                            echo '<td>'. $row['SUPERVISOR_NAME'].'</td>';
                            echo '<td>'. $row['EMPLOY_DATE'].'</td>';
                            echo '<td>'. $row['NATIONAL_ID'].'</td>';
                            echo '<td>'. $row['BIRTH_DATE'].'</td>';
                            echo '<td> <a type="button" class="btn btn-xs btn-info" href="supervisorsearch.php?action=edit & id='.$row['SUPERVISOR_ID'] . '" > SEARCH </a> ';
                            echo ' <a  type="button" class="btn btn-xs btn-warning" href="supervisoredit.php?action=edit & id='.$row['SUPERVISOR_ID'] . '"> EDIT </a> ';
                            echo ' <a  type="button" class="btn btn-xs btn-danger" href="supervisordel.php?type=supervisor&delete & id='.$row['SUPERVISOR_ID'] . '">DELETE </a> </td>';
                            echo '</tr> --> ';
                }
            ?> 
                                    
                                </tbody>
                            </table>
                        </div><?php include 'footer.php'; ?>