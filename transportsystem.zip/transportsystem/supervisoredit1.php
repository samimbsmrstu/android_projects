<?php include 'connection.php';
include 'topnav.php'; ?>
<body>
<?php
			$zz = $_POST['SUPERVISOR_ID'];
			$sname = $_POST['SUPERVISOR_NAME'];
		    $edate = $_POST['EMPLOY_DATE'];
		    $nid = $_POST['NATIONAL_ID'];
		    $bdate = $_POST['BIRTH_DATE'];
			
		
	 			$query = 'UPDATE supervisor set SUPERVISOR_NAME ="'.$sname.'",
					EMPLOY_DATE ="'.$edate.'",NATIONAL_ID ="'.$nid.'",BIRTH_DATE ="'.$bdate.'" WHERE
					SUPERVISOR_ID_ID ="'.$zz.'"';
					$result = mysqli_query($db, $query) or die(mysqli_error($db));
							
?>	
	<script type="text/javascript">
			alert("Update Successfull.");
			window.location = "supervisor.php";
		</script>
 <?php include 'footer.php'; ?>