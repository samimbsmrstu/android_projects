-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2022 at 02:20 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `busscheduledb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `confirmpassword` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fname`, `lname`, `user`, `password`, `confirmpassword`, `status`) VALUES
(1, 'Naznin Nahar', 'Bristy', 'nazninnahar363@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '21232f297a57a5a743894a0e4a801fc3', 'ADMIN'),
(6, 'Bristy', 'Islam', 'naznin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '21232f297a57a5a743894a0e4a801fc3', 'CLIENT');

-- --------------------------------------------------------

--
-- Table structure for table `bus`
--

CREATE TABLE `bus` (
  `BUS_ID` int(30) NOT NULL,
  `BUS_NAME` varchar(40) NOT NULL,
  `REG_NO` text NOT NULL,
  `BUS_TYPE` varchar(40) NOT NULL,
  `DRIVER_ID` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bus`
--

INSERT INTO `bus` (`BUS_ID`, `BUS_NAME`, `REG_NO`, `BUS_TYPE`, `DRIVER_ID`) VALUES
(5, 'Hanif Enterprise', 'SYL68575', 'NON AC', 1234),
(6, 'Shyamoli Paribahon', 'CTG54355', 'NON AC', 1235),
(7, 'Desh Travels', 'RAJ7849836', 'AC', 1356),
(8, 'Green Line', 'DHA67388', 'AC', 34559),
(9, 'EMAD', 'DHA67387', 'AC', 45656),
(10, 'Golden Line', 'DHA74764', 'AC', 45543);

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE `driver` (
  `DRIVER_ID` int(30) NOT NULL,
  `DRIVER_NAME` varchar(50) NOT NULL,
  `EMPLOY_DATE` date NOT NULL,
  `DRIVING_LICENSE` varchar(40) NOT NULL,
  `LICENSE_EXPIRE` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`DRIVER_ID`, `DRIVER_NAME`, `EMPLOY_DATE`, `DRIVING_LICENSE`, `LICENSE_EXPIRE`) VALUES
(1234, 'Rahim', '2022-01-01', 'RA7765', '2032-01-01'),
(1235, 'Karim', '2022-01-02', 'KA6655', '2042-02-02'),
(1356, 'Sajib', '2022-01-03', 'SA5654', '2035-02-07'),
(3455, 'Akash', '2030-01-01', 'AK5654', '2030-01-01'),
(34559, 'Rafiq', '2018-01-02', 'RA7765', '2030-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE `route` (
  `ROUTE_ID` int(50) NOT NULL,
  `START` varchar(50) NOT NULL,
  `FINISH` varchar(50) NOT NULL,
  `FAIR` float NOT NULL,
  `DISTANCE` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`ROUTE_ID`, `START`, `FINISH`, `FAIR`, `DISTANCE`) VALUES
(0, 'Gopalganj', 'Dhaka', 480, 150),
(2, 'Gopalganj', 'Gazipur', 580, 220),
(3, 'Gopalganj', 'Mawa', 250, 100),
(4, 'Gopalganj', 'Khulna', 120, 60),
(5, 'Dhaka', 'Khulna', 550, 220);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `SCHEDULE_ID` int(11) NOT NULL,
  `BUS_ID` int(11) NOT NULL,
  `ARRIVAL` date NOT NULL,
  `DEPARTURE` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`SCHEDULE_ID`, `BUS_ID`, `ARRIVAL`, `DEPARTURE`) VALUES
(4447, 5, '2022-02-03', '2022-03-03'),
(4448, 6, '2021-09-11', '2021-09-11'),
(4449, 7, '2022-03-03', '2022-03-04'),
(4450, 8, '2022-02-03', '2022-03-03'),
(4451, 9, '2022-02-03', '2022-03-03');

-- --------------------------------------------------------

--
-- Table structure for table `stop`
--

CREATE TABLE `stop` (
  `LOCATION_ID` int(50) NOT NULL,
  `LOCATION_NAME` varchar(40) NOT NULL,
  `ROUTE_ID` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stop`
--

INSERT INTO `stop` (`LOCATION_ID`, `LOCATION_NAME`, `ROUTE_ID`) VALUES
(0, 'candonis', 57),
(2, 'Bacolod', 23),
(3, 'Himamaylan', 3),
(4, 'lacarlota', 4);

-- --------------------------------------------------------

--
-- Table structure for table `supervisor`
--

CREATE TABLE `supervisor` (
  `SUPERVISOR_ID` int(40) NOT NULL,
  `SUPERVISOR_NAME` varchar(40) NOT NULL,
  `EMPLOY_DATE` date NOT NULL,
  `NATIONAL_ID` int(40) NOT NULL,
  `BIRTH_DATE` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supervisor`
--

INSERT INTO `supervisor` (`SUPERVISOR_ID`, `SUPERVISOR_NAME`, `EMPLOY_DATE`, `NATIONAL_ID`, `BIRTH_DATE`) VALUES
(453, 'Khalek', '2018-01-02', 2147483647, '1970-02-12'),
(345, 'Malek', '2020-01-01', 5353333, '1975-02-02'),
(123, 'Rashid', '2018-02-02', 3372897, '1974-02-02'),
(344, 'Rana', '2019-01-02', 85716272, '1974-02-12'),
(456, 'Arman', '2017-01-02', 687268763, '1979-02-12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bus`
--
ALTER TABLE `bus`
  ADD PRIMARY KEY (`BUS_ID`);

--
-- Indexes for table `driver`
--
ALTER TABLE `driver`
  ADD PRIMARY KEY (`DRIVER_ID`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`ROUTE_ID`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`SCHEDULE_ID`);

--
-- Indexes for table `stop`
--
ALTER TABLE `stop`
  ADD PRIMARY KEY (`LOCATION_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `bus`
--
ALTER TABLE `bus`
  MODIFY `BUS_ID` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `SCHEDULE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4452;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
